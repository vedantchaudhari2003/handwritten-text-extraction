import os

def rename_files(folder_path, file_prefix):
    files = os.listdir(folder_path)
    counter = 1

    for filename in files:
        ext = os.path.splitext(filename)[1]
        if ext in ['.pdf', '.png', '.jpg', '.jpeg']:
            new_name = f"{file_prefix}_{counter:03}{ext}"
            old_path = os.path.join(folder_path, filename)
            new_path = os.path.join(folder_path, new_name)
            os.rename(old_path, new_path)
            print(f"Renamed {filename} to {new_name}")
            counter += 1

if __name__ == "__main__":
    documents_folder = '/Users/vedantchaudhari/Desktop/TEST2/data/training_data/documents'
    rename_files(documents_folder, 'document')