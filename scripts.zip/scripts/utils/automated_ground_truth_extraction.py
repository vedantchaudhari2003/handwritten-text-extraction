import os
import easyocr
from pdfminer.high_level import extract_text

# Initialize EasyOCR reader
reader = easyocr.Reader(['en'])

def extract_text_from_image(image_path):
    result = reader.readtext(image_path, detail=0)  # Extract text without bounding box details
    text = ' '.join(result)
    print(f"Extracted text from image {image_path}: {text[:100]}...")  # Print first 100 characters for debug
    return text

def extract_text_from_pdf(pdf_path):
    text = extract_text(pdf_path)
    print(f"Extracted text from PDF {pdf_path}: {text[:100]}...")  # Print first 100 characters for debug
    return text

def save_text_to_file(text, file_path):
    with open(file_path, 'w') as f:
        f.write(text)

if __name__ == "__main__":
    doc_folder = '/content/drive/MyDrive/TEST2/data/handwritten_texts/Img'
    ground_truth_folder = '/content/drive/MyDrive/TEST2/data/handwritten_texts/ground_truth'

    # Ensure the ground truth folder exists
    os.makedirs(ground_truth_folder, exist_ok=True)

    for filename in os.listdir(doc_folder):
        file_path = os.path.join(doc_folder, filename)
        print(f"Processing file: {file_path}")  # Debug: Print the file being processed
        if filename.endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        elif filename.endswith(('.png', '.jpg', '.jpeg')):
            text = extract_text_from_image(file_path)
        else:
            print(f"Skipping unsupported file: {filename}")  # Debug: Print if file is unsupported
            continue

        if text.strip():
            ground_truth_path = os.path.join(ground_truth_folder, filename.rsplit('.', 1)[0] + '.txt')
            save_text_to_file(text, ground_truth_path)
            print(f"Saved extracted text to {ground_truth_path}")
        else:
            print(f"No text extracted from {filename}")