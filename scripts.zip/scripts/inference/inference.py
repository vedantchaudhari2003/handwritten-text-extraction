import torch
from transformers import BertTokenizer, BertForSequenceClassification
import easyocr
from pdfminer.high_level import extract_text
from PIL import Image
import os
from docx import Document
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction

# Load the model and tokenizer
model_path = '/content/drive/MyDrive/TEST2/models'
model = BertForSequenceClassification.from_pretrained(model_path)
tokenizer = BertTokenizer.from_pretrained(model_path)

# Set device to GPU if available, else CPU
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)
model.eval()

# Initialize EasyOCR reader
reader = easyocr.Reader(['en'])

# Define output folder
output_folder = '/content/drive/MyDrive/TEST2/data/handwritten_texts/output_files'

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Function to extract text from an image
def extract_text_from_image(image_path):
    result = reader.readtext(image_path, detail=0)  # Extract text without bounding box details
    text = ' '.join(result)
    print(f"Extracted text from image {image_path}: {text[:100]}...")  # Print first 100 characters for debug
    return text

# Function to extract text from a PDF
def extract_text_from_pdf(pdf_path):
    text = extract_text(pdf_path)
    print(f"Extracted text from PDF {pdf_path}: {text[:100]}...")  # Print first 100 characters for debug
    return text

# Function to preprocess text for BERT model
def preprocess_text(text, tokenizer, max_length=512):
    tokens = tokenizer.encode_plus(
        text,
        padding='max_length',
        truncation=True,
        max_length=max_length,
        return_tensors='pt',
        return_attention_mask=True
    )
    return tokens['input_ids'], tokens['attention_mask']

# Function to predict the class of the text
def predict(text, model, tokenizer, device):
    input_ids, attention_mask = preprocess_text(text, tokenizer)
    input_ids = input_ids.to(device)
    attention_mask = attention_mask.to(device)

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
        logits = outputs.logits

    probabilities = torch.nn.functional.softmax(logits, dim=-1)
    predicted_class = torch.argmax(probabilities, dim=-1)

    return predicted_class.item(), probabilities.cpu().numpy()

# Function to clean text by removing non-XML compatible characters
def clean_text(text):
    return ''.join(c for c in text if ord(c) in range(32, 127) or c in '\t\n\r')

# Function to save text to a Word document
def save_to_word(text, output_path):
    doc = Document()
    doc.add_paragraph(text)
    doc.save(output_path)

# Function to calculate BLEU score with smoothing
def calculate_bleu(reference, hypothesis):
    reference = [reference.split()]
    hypothesis = hypothesis.split()
    smoothing_function = SmoothingFunction().method4
    return sentence_bleu(reference, hypothesis, smoothing_function=smoothing_function)

if __name__ == "__main__":
    doc_folder = '/content/drive/MyDrive/TEST2/data/documents'
    ground_truth_folder = '/content/drive/MyDrive/TEST2/data/documents/ground_truth'
    #output_path = '/content/drive/MyDrive/TEST2/data/documents/output_files'

    files = os.listdir(doc_folder)  # Process all files

    bleu_scores = []
    all_ground_truths = []  # Initialize this list
    all_extracted_texts = []  # Initialize this list

    for filename in files:
        file_path = os.path.join(doc_folder, filename)
        print(f"Processing file: {file_path}")  # Debug: Print the file being processed
        if filename.endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        elif filename.endswith(('.png', '.jpg', '.jpeg')):
            text = extract_text_from_image(file_path)
        else:
            print(f"Skipping unsupported file: {filename}")  # Debug: Print if file is unsupported
            continue

        if not text.strip():
            print(f"No text extracted from {filename}")  # Debug: Print if no text is extracted
        else:
            text = clean_text(text)  # Clean the text to remove incompatible characters
            
            # Save the text to a separate Word document
            output_file = os.path.join(output_folder, f"{os.path.splitext(filename)[0]}.docx")
            save_to_word(text, output_file)
            print(f"Extracted text saved to {output_file}")

            # Load ground truth
            ground_truth_path = os.path.join(ground_truth_folder, filename.replace('.pdf', '.txt').replace('.png', '.txt').replace('.jpg', '.txt').replace('.jpeg', '.txt'))
            if os.path.exists(ground_truth_path):
                with open(ground_truth_path, 'r') as gt_file:
                    ground_truth = gt_file.read().strip()
                
                # Print both extracted and ground truth texts for debugging
                print(f"Extracted Text: {text[:100]}...")
                print(f"Ground Truth: {ground_truth[:100]}...")

                # Calculate BLEU score
                bleu_score = calculate_bleu(ground_truth, text)
                bleu_scores.append(bleu_score)

                # Append for additional metrics
                all_ground_truths.append(ground_truth)
                all_extracted_texts.append(text)
            else:
                print(f"Ground truth file not found for {filename}")

    # Calculate and print average BLEU score
    avg_bleu_score = sum(bleu_scores) / len(bleu_scores) if bleu_scores else 0
    print(f"Average BLEU Score: {avg_bleu_score}")

    # Calculate additional metrics
    if all_ground_truths and all_extracted_texts:
        accuracy = accuracy_score(all_ground_truths, all_extracted_texts)
        precision = precision_score(all_ground_truths, all_extracted_texts, average='weighted')
        recall = recall_score(all_ground_truths, all_extracted_texts, average='weighted')
        f1 = f1_score(all_ground_truths, all_extracted_texts, average='weighted')

        print(f"Accuracy: {accuracy}")
        print(f"Precision: {precision}")
        print(f"Recall: {recall}")
        print(f"F1 Score: {f1}")
    else:
        print("No ground truth or extracted texts available for additional metrics.")