import torch
from torch.utils.data import Dataset, DataLoader
import os

# Directories for printed and handwritten texts
printed_texts_dir = "/content/drive/MyDrive/TEST2/data/printed_texts"
handwritten_texts_dir = "/content/drive/MyDrive/TEST2/data/handwritten_texts"

# Function to read text files with proper encoding handling
def read_text_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            return file.read()
    except UnicodeDecodeError:
        try:
            with open(filepath, 'r', encoding='latin1') as file:
                return file.read()
        except UnicodeDecodeError as e:
            print(f"Error reading {filepath}: {e}")
            return None

# Collecting texts from both directories
def collect_texts():
    printed_texts = []
    handwritten_texts = []

    for filename in os.listdir(printed_texts_dir):
        filepath = os.path.join(printed_texts_dir, filename)
        if os.path.isfile(filepath):
            text = read_text_file(filepath)
            if text:
                printed_texts.append(text)

    for filename in os.listdir(handwritten_texts_dir):
        filepath = os.path.join(handwritten_texts_dir, filename)
        if os.path.isfile(filepath):
            text = read_text_file(filepath)
            if text:
                handwritten_texts.append(text)

    return printed_texts, handwritten_texts

# Tokenization placeholder (replace with your actual tokenizer)
def dummy_tokenize(text):
    return {
        'input_ids': [ord(char) for char in text],
        'token_type_ids': [0] * len(text),
        'attention_mask': [1] * len(text)
    }

# Tokenize all texts
def tokenize_texts(all_texts):
    encoded_texts = [dummy_tokenize(text) for text in all_texts]
    return encoded_texts

# Define maximum sequence length
max_seq_length = 512  # Adjust this based on your needs and model requirements

# Pad or truncate sequences
def pad_truncate(sequence, max_length):
    if len(sequence) > max_length:
        return sequence[:max_length]
    else:
        return sequence + [0] * (max_length - len(sequence))

# Prepare inputs for DataLoader
def prepare_inputs(encoded_texts):
    input_ids = torch.tensor([pad_truncate(et['input_ids'], max_seq_length) for et in encoded_texts])
    token_type_ids = torch.tensor([pad_truncate(et['token_type_ids'], max_seq_length) for et in encoded_texts])
    attention_mask = torch.tensor([pad_truncate(et['attention_mask'], max_seq_length) for et in encoded_texts])
    return input_ids, attention_mask

# Define dataset class
class TextDataset(Dataset):
    def __init__(self, input_ids, attention_mask):
        self.input_ids = input_ids
        self.attention_mask = attention_mask

    def __len__(self):
        return len(self.input_ids)

    def __getitem__(self, idx):
        return {
            'input_ids': self.input_ids[idx],
            'attention_mask': self.attention_mask[idx],
        }

# Create DataLoader
def create_dataloader(batch_size=2, shuffle=True):
    printed_texts, handwritten_texts = collect_texts()
    all_texts = printed_texts + handwritten_texts
    encoded_texts = tokenize_texts(all_texts)
    input_ids, attention_mask = prepare_inputs(encoded_texts)

    # Split data into training and validation sets
    split_idx = int(0.8 * len(input_ids))
    train_input_ids, val_input_ids = input_ids[:split_idx], input_ids[split_idx:]
    train_attention_mask, val_attention_mask = attention_mask[:split_idx], attention_mask[split_idx:]

    train_dataset = TextDataset(train_input_ids, train_attention_mask)
    val_dataset = TextDataset(val_input_ids, val_attention_mask)

    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle)
    val_dataloader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

    return train_dataloader, val_dataloader

# Debug print statements to ensure the function runs correctly
if __name__ == "__main__":
    train_dataloader, val_dataloader = create_dataloader()
    print(f"Train Dataloader: {train_dataloader}")
    print(f"Val Dataloader: {val_dataloader}")