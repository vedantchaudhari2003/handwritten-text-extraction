import os
import pytesseract
from pdfminer.high_level import extract_text
from PIL import Image
import torch
from transformers import BertTokenizer

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

def extract_text_from_image(image_path):
    return pytesseract.image_to_string(Image.open(image_path))

def extract_text_from_pdf(pdf_path):
    return extract_text(pdf_path)

def preprocess_documents(doc_folder, tokenizer, max_length=512):
    input_ids_list = []
    token_type_ids_list = []
    attention_mask_list = []

    for filename in os.listdir(doc_folder):
        file_path = os.path.join(doc_folder, filename)
        if filename.endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        elif filename.endswith(('.png', '.jpg', '.jpeg')):
            text = extract_text_from_image(file_path)
        else:
            continue

        tokens = tokenizer.encode_plus(
            text,
            padding='max_length',
            truncation=True,
            max_length=max_length,
            return_tensors='pt',
            return_attention_mask=True
        )

        input_ids_list.append(tokens['input_ids'])
        token_type_ids_list.append(tokens['token_type_ids'])
        attention_mask_list.append(tokens['attention_mask'])

    return {
        'input_ids': torch.cat(input_ids_list, dim=0),
        'token_type_ids': torch.cat(token_type_ids_list, dim=0),
        'attention_mask': torch.cat(attention_mask_list, dim=0)
}

if __name__ == "__main__":
    doc_folder = '/Users/vedantchaudhari/Downloads/archive-2/data/pdf_resumes/BPO'
    encoded_dataset = preprocess_documents(doc_folder, tokenizer)

    output_path = '/Users/vedantchaudhari/Desktop/TEST2/training_data/encoded_dataset1.pt'
    torch.save(encoded_dataset, output_path)
    print("Encoded dataset saved successfully.")