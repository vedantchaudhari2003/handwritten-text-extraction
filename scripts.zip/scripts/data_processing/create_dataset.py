import os
import pandas as pd

def create_dataset(documents_folder, labels_folder, output_csv):
    data = {'filename': [], 'text': []}
    
    for label_file in os.listdir(labels_folder):
        if label_file.endswith('.txt'):
            file_path = os.path.join(labels_folder, label_file)
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
                data['filename'].append(label_file)
                data['text'].append(text)
    
    df = pd.DataFrame(data)
    df.to_csv(output_csv, index=False)
    print(f"Dataset saved to {output_csv}")

if __name__ == "__main__":
    documents_folder = '/Users/vedantchaudhari/Desktop/TEST2/training_data/documents'
    labels_folder = '/Users/vedantchaudhari/Desktop/TEST2/training_data/labels'
    output_csv = 'dataset.csv'
    create_dataset(documents_folder, labels_folder, output_csv)