from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

paragraph = doc.add_paragraph("Your extracted text here")
paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER  # Aligning text to center
run = paragraph.add_run()
run.font.size = Pt(12)  # Setting font size
# Additional formatting as needed

doc.save("/content/drive/MyDrive/TEST2/data/handwritten_texts/output_files")