# identify_document.py

import os

def identify_document(file_path):
    _, file_extension = os.path.splitext(file_path)
    if file_extension.lower() == '.pdf':
        return 'pdf'
    elif file_extension.lower() in ('.jpg', '.jpeg', '.png'):
        return 'image'
    elif file_extension.lower() == '.docx':
        return 'docx'
    else:
        raise ValueError(f"Unsupported file format: {file_extension}")

if __name__ == "__main__":
    file_path = '/Users/vedantchaudhari/Desktop/TEST2/data/documents/example.docx'  # Replace with actual file path
    document_type = identify_document(file_path)
    print(f"Document type: {document_type}")