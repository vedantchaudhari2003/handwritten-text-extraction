import os
from PyPDF2 import PdfReader
import pytesseract
from PIL import Image
import docx

def is_handwritten(image_path):
    # Placeholder function to determine if text is handwritten
    # You may need a more sophisticated method or manual annotation
    return True  # Assuming all images are handwritten for this example

def extract_text_from_handwritten(image_path):
    image = Image.open(image_path)
    text = pytesseract.image_to_string(image, config='--psm 6')
    return text

def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def extract_text_from_image(image_path):
    image = Image.open(image_path)
    text = pytesseract.image_to_string(image)
    return text

def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = ""
    for paragraph in doc.paragraphs:
        text += paragraph.text + "\n"
    return text

def extract_text_from_document(document_path):
    ext = os.path.splitext(document_path)[1].lower()
    if ext == '.pdf':
        return extract_text_from_pdf(document_path)
    elif ext in ['.png', '.jpg', '.jpeg']:
        if is_handwritten(document_path):
            return extract_text_from_handwritten(document_path)
        else:
            return extract_text_from_image(document_path)
    elif ext == '.docx':
        return extract_text_from_docx(document_path)
    else:
        raise ValueError(f"Unsupported file extension: {ext}")

if __name__ == "__main__":
    documents_folder = '/Users/vedantchaudhari/Desktop/TEST2/data/documents'
    output_folder = '/Users/vedantchaudhari/Desktop/TEST2/data/extracted_texts'
    os.makedirs(output_folder, exist_ok=True)

    for document_name in os.listdir(documents_folder):
        document_path = os.path.join(documents_folder, document_name)
        try:
            extracted_text = extract_text_from_document(document_path)
            output_path = os.path.join(output_folder, f"{os.path.splitext(document_name)[0]}.txt")
            with open(output_path, 'w', encoding='utf-8') as output_file:
                output_file.write(extracted_text)
            print(f"Extracted text from {document_name} and saved to {output_path}")
        except Exception as e:
            print(f"Failed to extract text from {document_name}: {e}")