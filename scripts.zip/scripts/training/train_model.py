import sys
import os
import torch
from transformers import BertForSequenceClassification, Trainer, TrainingArguments, AutoTokenizer

# Add the 'data_processing' folder to the Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
data_processing_path = os.path.join(parent_dir, 'data_processing')
sys.path.append(data_processing_path)

try:
    from create_dataloader import create_dataloader

    dataloader_output = create_dataloader(batch_size=2)

    if isinstance(dataloader_output, tuple) and len(dataloader_output) >= 2:
        train_dataloader, val_dataloader = dataloader_output[:2]
    else:
        raise ValueError("Expected create_dataloader to return at least two dataloaders")

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)
    model.to(device)

    tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")

    training_args = TrainingArguments(
        output_dir='./results',
        num_train_epochs=3,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,
        warmup_steps=500,
        weight_decay=0.01,
        logging_dir='./logs',
        logging_steps=10,
        eval_strategy="epoch",
        save_steps=500,
        save_total_limit=2,
    )

    def compute_metrics(pred):
        labels = pred.label_ids
        preds = pred.predictions.argmax(-1)
        accuracy = (preds == labels).astype(float).mean()
        return {"accuracy": accuracy}

    # Add labels to dataset and dataloader
    def add_labels_to_dataloader(dataloader, labels):
        class LabeledDataset(torch.utils.data.Dataset):
            def __init__(self, inputs, masks, labels):
                self.inputs = inputs
                self.masks = masks
                self.labels = labels

            def __len__(self):
                return len(self.inputs)

            def __getitem__(self, idx):
                return {
                    'input_ids': self.inputs[idx],
                    'attention_mask': self.masks[idx],
                    'labels': self.labels[idx]
                }

        new_inputs = []
        new_masks = []
        new_labels = []

        for batch in dataloader:
            new_inputs.append(batch['input_ids'])
            new_masks.append(batch['attention_mask'])
            # Dummy labels for now
            new_labels.append(torch.zeros_like(batch['input_ids'][:, 0]))

        new_dataset = LabeledDataset(torch.cat(new_inputs), torch.cat(new_masks), torch.cat(new_labels))
        new_dataloader = torch.utils.data.DataLoader(new_dataset, batch_size=dataloader.batch_size)

        return new_dataloader

    train_dataloader = add_labels_to_dataloader(train_dataloader, torch.zeros(len(train_dataloader.dataset)))
    val_dataloader = add_labels_to_dataloader(val_dataloader, torch.zeros(len(val_dataloader.dataset)))

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataloader.dataset,
        eval_dataset=val_dataloader.dataset,
        tokenizer=tokenizer,
        compute_metrics=compute_metrics
    )

    trainer.train()

except Exception as e:
    print(f"Error occurred: {e}")
    sys.exit(1)