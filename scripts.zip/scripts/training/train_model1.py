#train_model1.py

import torch
from transformers import BertForSequenceClassification, BertTokenizer
from torch.utils.data import DataLoader
from create_dataloader import TextDataset  # Import your custom dataset class

# Initialize BERT model and tokenizer
model = BertForSequenceClassification.from_pretrained('bert-base-uncased')
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# Define optimizer and learning rate scheduler (adjust as needed)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-5)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.1)

# Move model to appropriate device (GPU if available)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)

# Define batch size and load your encoded dataset
batch_size = 2  # Adjust based on your hardware capabilities

# Load encoded dataset (assuming you have encoded_dataset.pt in the directory)
encoded_dataset_path = '/Users/vedantchaudhari/Desktop/TEST2/training_data/encoded_dataset.pt'
encoded_dataset = torch.load(encoded_dataset_path)

# Extract input_ids, token_type_ids, attention_mask from encoded dataset
input_ids = torch.tensor(encoded_dataset['input_ids'])
token_type_ids = torch.tensor(encoded_dataset['token_type_ids'])
attention_mask = torch.tensor(encoded_dataset['attention_mask'])

# Create DataLoader
dataset = TextDataset(input_ids, token_type_ids, attention_mask)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# Training loop
epochs = 3  # Adjust as needed
for epoch in range(epochs):
    model.train()
    total_loss = 0.0

    for batch in dataloader:
        input_ids_batch = batch['input_ids'].to(device)
        token_type_ids_batch = batch['token_type_ids'].to(device)
        attention_mask_batch = batch['attention_mask'].to(device)

        # Forward pass
        outputs = model(input_ids=input_ids_batch, token_type_ids=token_type_ids_batch, attention_mask=attention_mask_batch)
        logits = outputs.logits
        labels = torch.zeros_like(logits)  # Dummy labels since you don't have actual labels

        # Compute loss (adjust based on your specific task)
        loss = torch.nn.functional.cross_entropy(logits, labels)

        # Backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    # Print average loss for the epoch
    average_train_loss = total_loss / len(dataloader)
    print(f"Epoch {epoch + 1}/{epochs}:")
    print(f"  Average Training Loss: {average_train_loss:.4f}")

# Save the trained model and tokenizer
output_dir = '/Users/vedantchaudhari/Desktop/TEST2/models'
model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)

print(f"Model and tokenizer saved to {output_dir}")